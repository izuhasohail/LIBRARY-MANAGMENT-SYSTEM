package com.example.my_lms;

import javafx.event.ActionEvent;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;


public class AdminController implements Initializable {
    public ImageView ivBack;

    public Label lblAdminName;
    public Label lblAddStudentNotification;
    public Label lblIssueBookNotification;
    public Label lblReturnBookNotification;
    final String dbUrl = "jdbc:mysql://localhost:3306/my_lms?";
    final String userName = "root";
    final String password = "zuha";





    Connection con = null;
    Statement stnt = null;




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl, userName, password);
            stnt = con.createStatement();

            String query = "select count(*) from addstudent";
            ResultSet rs = stnt.executeQuery(query);
            rs.next();
            int count  = rs.getInt(1);
            if(count!=0) {
                lblAddStudentNotification.setText("" + count);
            }

            query = "select count(*) from issuebook";
            rs = stnt.executeQuery(query);
            rs.next();
            count  = rs.getInt(1);
            if(count!=0) {
                lblIssueBookNotification.setText("" + count);
            }

            query = "select count(*) from returnbook";
            rs = stnt.executeQuery(query);
            rs.next();
            count  = rs.getInt(1);
            if(count!=0) {
                lblReturnBookNotification.setText("" + count);
            }


            String sql = "SELECT username" +" FROM admin";
            rs = stnt.executeQuery(sql);

            while(rs.next()) {
                lblAdminName.setText("            "+rs.getString("username"));
            }

            stnt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }





    public void Back(MouseEvent mouseEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Login.fxml"));
        //Stage stage=new Stage();
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();

    }

    public void Books(MouseEvent mouseEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("BookList.fxml"));
        Stage stage=new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Books");
        stage.setScene(scene);
        stage.show();

    }

    public void ChangePasswordAction(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("AdminPassword.fxml"));
        Stage stage=new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Change Admin Password");
        stage.setScene(scene);
        stage.show();
    }

    public void LogoutAction(ActionEvent actionEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Library Management System");
        stage.setScene(scene);
        stage.show();
    }

    public void IssueBook(MouseEvent mouseEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("AdminIssueBook.fxml"));
        //Stage stage=new Stage();
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Issue Book");
        stage.setScene(scene);
        stage.show();

    }

    public void Statistics(MouseEvent mouseEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Statistics.fxml"));
        Stage stage=new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Statistics");
        stage.setScene(scene);
        stage.show();
    }

    public void ReturnBook(MouseEvent mouseEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("AdminReturnBook.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Return Book");
        stage.setScene(scene);
        stage.show();

    }

    public void AddStudent(MouseEvent mouseEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("AddStudent.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Add Student");
        stage.setScene(scene);
        stage.show();

    }

    public void RemoveStudent(MouseEvent mouseEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("RemoveStudent.fxml"));
        Stage stage= new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Remove Student");
        stage.setScene(scene);
        stage.show();

    }
}
