package com.example.my_lms;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class AdminPasswordController {


    final String dbUrl = "jdbc:mysql://localhost:3306/my_lms?";
    final String userName = "root";
    final String password = "zuha";
    public TextField tfNewPassword;
    public TextField tfConfirmPassword;
    public ImageView ivBack;

    Connection con = null;
    Statement stnt = null;


    public void ChangeAction(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.ERROR);
        if(tfNewPassword.getText().length()==0 || tfConfirmPassword.getText().length()==0){
            alert.setContentText("All fields are not filled");
            alert.show();
            return;
        }
        if(tfNewPassword.getText().equals(tfConfirmPassword.getText())) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection(dbUrl, userName, password);
                stnt = con.createStatement();

                String query = "UPDATE admin SET password ='" + tfNewPassword.getText() + "'   ";
                PreparedStatement ps = con.prepareStatement(query);
                ps.executeUpdate();

                stnt.close();
                con.close();
                Alert a = new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("Password Changed Successfully!...");
                a.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else{

            alert.setContentText("Password in both fields are not same");
            alert.show();
        }

    }

    public void ivBackAction(MouseEvent mouseEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Admin.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Admin");
        stage.setScene(scene);
        stage.show();

    }
}
