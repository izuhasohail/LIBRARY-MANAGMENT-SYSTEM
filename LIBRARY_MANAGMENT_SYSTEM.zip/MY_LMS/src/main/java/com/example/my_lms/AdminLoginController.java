package com.example.my_lms;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.w3c.dom.events.MouseEvent;

import java.io.IOException;
import java.sql.*;



public class AdminLoginController {


    public PasswordField pfPass;
    public TextField tfAdminName;
    public Button btnLogin;
    public ImageView ivBack;
    final String dbUrl = "jdbc:mysql://localhost:3306/my_lms?";
    final String userName = "root";
    final String password = "zuha";

    Connection con = null;
    Statement stnt = null;

    public void Reset(ActionEvent actionEvent) {

        pfPass.setText("");
        tfAdminName.setText("");

    }

    public void LOGIN(ActionEvent actionEvent) {

        Alert a = new Alert(Alert.AlertType.ERROR);


        if(tfAdminName.getText().length()==0 || pfPass.getText().length()==0)
        {
            a.setContentText("Please fill all fields");
            a.show();
            return;
        }
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl, userName, password);
            stnt = con.createStatement();

            String sql = "SELECT *  FROM admin";
            ResultSet rs = stnt.executeQuery(sql);
            boolean present = false;
            while(rs.next()) {
                if (rs.getString("username").equalsIgnoreCase(tfAdminName.getText()) && (rs.getString("password").equalsIgnoreCase(pfPass.getText()))) {
                    present = true;
                    break;
                }
            }
            if(present){
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Admin.fxml"));
                Stage stage=(Stage)btnLogin.getScene().getWindow();
                Scene scene = new Scene(fxmlLoader.load());
                stage.setTitle("Admin");
                stage.setScene(scene);
                stage.show();
            }
            else {

                a.setContentText("Incorrect Name or Password");
                a.show();
            }
            stnt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    public void ivBack(javafx.scene.input.MouseEvent mouseEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Login.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Library Management System");
        stage.setScene(scene);
        stage.show();



    }
}
