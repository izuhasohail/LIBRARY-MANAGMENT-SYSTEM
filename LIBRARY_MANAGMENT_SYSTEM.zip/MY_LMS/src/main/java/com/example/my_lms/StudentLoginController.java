package com.example.my_lms;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;

public class StudentLoginController {
    @FXML
    public Button btnLogin;
    public PasswordField pfPass;
    public TextField tfStudentId;
    @FXML
    private ImageView ivBack;
    final String dbUrl = "jdbc:mysql://localhost:3306/my_lms?";
    final String userName = "root";
    final String password = "zuha";

    Connection con = null;
    Statement stnt = null;

    public void LOGIN(ActionEvent actionEvent) {


        if(tfStudentId.getText().length()==0 || pfPass.getText().length()==0 ){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("All fields are not filled!...");
            alert.show();
            return;
        }
        try{

        HelloApplication.studID=Integer.parseInt(tfStudentId.getText());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl, userName, password);
            stnt = con.createStatement();

            String sql = "SELECT id, password " +" FROM student";
            ResultSet rs = stnt.executeQuery(sql);
            boolean present = false;
            while(rs.next()) {


                if (rs.getInt("id")==Integer.parseInt(tfStudentId.getText()) && (rs.getString("password").equals(pfPass.getText()))) {
                    present = true;
                    break;
                }
            }
            if(present){

                tfStudentId.setText("");
                pfPass.setText("");
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Student.fxml"));
                Stage stage=(Stage)ivBack.getScene().getWindow();
                Scene scene = new Scene(fxmlLoader.load());
                stage.setTitle("Student");
                stage.setScene(scene);
                stage.show();
            }
            else {


                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("Incorrect ID or Password");
                a.show();
            }
            stnt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }}
        catch (NumberFormatException e){
            Alert x=new Alert(Alert.AlertType.ERROR);
            x.setContentText("ID must be an integer");
            x.show();
        }

    }

    public void SignUp(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("StudentSignUp.fxml"));
        Stage stage= new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("SignUp");
        stage.setScene(scene);
        stage.show();

    }

    public void Reset(ActionEvent actionEvent) {

        tfStudentId.setText("");
        pfPass.setText("");
    }

    public void ivBackAction(MouseEvent mouseEvent) throws IOException {

       /* FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Login.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();*/
        Stage stage = (Stage)ivBack.getScene().getWindow();
        stage.close();

    }
}
