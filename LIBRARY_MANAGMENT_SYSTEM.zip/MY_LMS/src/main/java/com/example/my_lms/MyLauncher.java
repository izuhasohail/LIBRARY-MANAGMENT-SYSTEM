package com.example.my_lms;

public class MyLauncher {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
