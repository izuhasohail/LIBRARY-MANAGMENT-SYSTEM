package com.example.my_lms;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.event.ActionEvent;

public class Login {

    public Button btnClose;
    public Button btnAdmin;
    public Button btnStudent;

    public void StudentLoginAction(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("StudentLogin.fxml"));
        Stage stage=(Stage)btnStudent.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Student Login");
        stage.setScene(scene);
        stage.show();
    }

    public void AdminLoginAction(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("AdminLogin.fxml"));
        Stage stage=(Stage)btnAdmin.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Admin Login");
        stage.setScene(scene);
        stage.show();
    }

    public void CloseAction(ActionEvent actionEvent) {
        Stage stage = (Stage) btnClose.getScene().getWindow();
        stage.close();
    }

}
