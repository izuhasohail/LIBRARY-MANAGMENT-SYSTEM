package com.example.my_lms;

import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;


import javafx.scene.input.MouseEvent;

public class StudentController implements Initializable {
    @FXML
    public MenuItem mbShowProfile;
    public MenuItem mbEditProfile;
    public MenuItem mbChangePass;
    public MenuItem mbLogout;
    public ImageView ivReturnBook;
    public ImageView ivIssueBook;
    public Label lblStudentName;

    @FXML
    ImageView ivBack;


    final String dbUrl = "jdbc:mysql://localhost:3306/my_lms?";
    final String userName = "root";
    final String password = "zuha";
    Connection con = null;
    Statement stnt = null;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dbUrl, userName, password);
            stnt = con.createStatement();

            String query = "SELECT name, id FROM student";
            ResultSet rs = stnt.executeQuery(query);
            while (rs.next()) {
                if (HelloApplication.studID == rs.getInt("id")) {
                    lblStudentName.setText(rs.getString("name"));
                    break;
                }
            }
        } catch (ClassNotFoundException | SQLException e ) {
            throw new RuntimeException(e);
        }



    }

    public void ShowProfileAction(Event actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Profile.fxml"));
        Stage stage=new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Student Profile");
        stage.setScene(scene);
        stage.show();

    }

    public void EditProfileAction(Event actionEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("EditProfile.fxml"));
        Stage stage=new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Edit student Profile");
        stage.setScene(scene);
        stage.show();

    }

    public void ChangePasswordAction(Event actionEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("StudentPassword.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Student Password");
        stage.setScene(scene);
        stage.show();

    }

    public void LogOutAction(Event actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Login.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Library Management System");
        stage.setScene(scene);
        stage.show();

    }

    public void Back(MouseEvent mouseEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("StudentLogin.fxml"));
        Stage stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Library Management System");
        stage.setScene(scene);
        stage.show();

    }

    public void IssueBook(MouseEvent mouseEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("IssueBook.fxml"));
        Stage stage=new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Issue Book");
        stage.setScene(scene);
        stage.show();

    }

    public void ReturnBook(MouseEvent mouseEvent) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("ReturnBook.fxml"));
        Stage stage=new Stage();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Return Book");
        stage.setScene(scene);
        stage.show();

    }
}
