package com.example.my_lms;

import javafx.event.ActionEvent;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;


public class AddStudentController implements Initializable {
    public TextField tfName;
    public TextField tfFatherName;
    public TextField tfEmail;
    public ImageView ivBack;
    public TextField tfCourse;
    public Label lblMessage;


    final String dbUrl = "jdbc:mysql://localhost:3306/my_lms?";
    final String userName = "root";
    final String password = "zuha";
    public TextField tfDob;

    private String studPassword = null;
    private int count, id;
    private java.sql.Date sqlDate;

    Connection con = null;
    Statement stnt = null;






    public void CancelAction(ActionEvent actionEvent) throws SQLException {

        if(count == 0){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Action not Performed because there is no Student data to add or cancel");
            a.show();
            return;
        }

        remove();


        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setContentText("Student Data Canceled Sucessfully!...");
        a.show();

        displayData();

    }

    public void ivBack(MouseEvent mouseEvent) throws IOException {
        Stage stage = (Stage) ivBack.getScene().getWindow();
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Admin.fxml"));
        //Stage stage=new Stage();
        stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Admin");
        stage.setScene(scene);
        stage.show();


    }

    public void AddAction(ActionEvent actionEvent) throws SQLException {
        if(count == 0){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Action not Performed because there is no Student data to add");
            a.show();
            return;
        }
        try {

            con = DriverManager.getConnection(dbUrl, userName, password);
            stnt = con.createStatement();

            //  java.sql.Date sqlDate = new java.sql.Date(HelloApplication.addstudent.get(0).dateOfBirth.getTime());

            String sql = "INSERT INTO student(name, fathername, dob, emailaddress, course, password)" + "Values('"+tfName.getText()+"', '"+tfFatherName.getText() +"', '"+sqlDate+"', '"+ tfEmail.getText()+"', '"+tfCourse.getText()+"', '"+studPassword+"')";
            stnt.execute(sql);


            stnt.close();
            con.close();

            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setContentText("Student Data Added Sucessfully!...");
            a.show();

        }
        catch (Exception e){
            e.printStackTrace();
        }
        remove();
        displayData();

    }

    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        displayData();
    }

    public void displayData(){
        try {
            con = DriverManager.getConnection(dbUrl, userName, password);
            stnt = con.createStatement();

            String query = "select count(*) from addstudent";
            ResultSet rs = stnt.executeQuery(query);
            rs.next();
            count = rs.getInt(1);
            if(count == 0){
                lblMessage.setText("There is no student data to add");
                tfName.setText("");
                tfFatherName.setText("");
                tfDob.setText("");
                tfEmail.setText("");
                tfCourse.setText("");
            }
            else{
                query = "SELECT * FROM addstudent";
                rs = stnt.executeQuery(query);
                rs.next();
                tfName.setText(rs.getString("name"));
                tfFatherName.setText(rs.getString("fathername"));
                tfDob.setText(String.valueOf(rs.getDate("dob")));
                sqlDate = rs.getDate("dob");
                tfEmail.setText(rs.getString("emailaddress"));
                tfCourse.setText(rs.getString("course"));
                studPassword = rs.getString("password");
                id = rs.getInt("id");



            }
            stnt.close();
            con.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public void remove() throws SQLException {
        con = DriverManager.getConnection(dbUrl, userName, password);
        stnt = con.createStatement();

        String query = "Delete from addstudent where id = "+ id + " ";
        stnt.execute(query);

        stnt.close();
        con.close();

    }


    public void ivBackAction(MouseEvent mouseEvent) throws IOException {
        Stage stage = (Stage) ivBack.getScene().getWindow();
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Admin.fxml"));
        //Stage stage=new Stage();
        stage=(Stage)ivBack.getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Admin");
        stage.setScene(scene);
        stage.show();
    }
}
