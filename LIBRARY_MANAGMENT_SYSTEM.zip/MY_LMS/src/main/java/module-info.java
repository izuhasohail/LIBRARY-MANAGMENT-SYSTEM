module com.example.my_lms {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.java;


    opens com.example.my_lms to javafx.fxml;
    exports com.example.my_lms;
}